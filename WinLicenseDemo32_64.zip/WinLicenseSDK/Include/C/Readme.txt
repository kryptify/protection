
Just include "WinlicenseSDK.h" in your source code.

The rest of the files are used by WinlicenseSDK.h if required.


