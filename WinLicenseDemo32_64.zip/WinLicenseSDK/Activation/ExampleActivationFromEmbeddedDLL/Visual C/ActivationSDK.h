#define  EVENT_SHOW_ACTIVATION                              1
#define  EVENT_CHECK_RESPONSE                               2
#define  EVENT_SHOW_DEACTIVATION                            3

#define  RESPONSE_ACTIVATION_OK                             0
#define  RESPONSE_DEACTIVATION_OK                           0
#define  RESPONSE_ERROR_KEY_NOT_FOUND                       1
#define  RESPONSE_ERROR_MAX_DEVICES_REACHED                 2
#define  RESPONSE_ERROR_NO_MORE_ACTIVATIONS_ALLOWED         3
#define  RESPONSE_ERROR_NO_MORE_DEACTIVATIONS_ALLOWED       4
#define  RESPONSE_ERROR_DEVICE_NOT_FOUND                    5
#define  RESPONSE_ERROR_WRONG_DATA_RECEIVED                 6
#define  RESPONSE_ERROR_KEY_DISABLED_BY_SELLER              7
#define  RESPONSE_ERROR_KEY_EXPIRED                         8
#define  RESPONSE_ERROR_NO_MORE_DIFFERENT_DEVICES_ALLOWED   9
#define  RESPONSE_ERROR_CANNOT_INSTALL_LICENSE              50
#define  RESPONSE_ERROR_WINSOCK_ERROR                       100

#define  FORM_RESPONSE_PROCESS_ACTIVATION_KEY               0
#define  FORM_RESPONSE_TERMINATE_APPLICATION                1
#define  FORM_RESPONSE_RESTART_APPLICATION                  2
#define  FORM_RESPONSE_SHOW_ACTIVATION_FORM_AGAIN           3