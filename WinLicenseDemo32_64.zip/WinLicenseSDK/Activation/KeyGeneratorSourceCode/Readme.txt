The key generator is shipped as a compiled application under the /PHP/bin folder.

If you need the source code to compile it under a different platform, please, contact us at support@oreans.com

