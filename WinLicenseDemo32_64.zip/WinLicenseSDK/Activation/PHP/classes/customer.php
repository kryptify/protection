<?php 

/******************************************************************************
 * Customer Class
 *****************************************************************************/
class Customer {
    public $salutation = "";
    public $first_name = "";
    public $last_name = "";
    public $job_title = "";
    public $organization = "";
    public $email = "";
    public $phone = "";
    public $fax = "";
    public $address1 = "";
    public $address2 = "";
    public $city = "";
    public $zip_code = "";
    public $state = "";
    public $country = "";
    public $notes = "";
}

?>

