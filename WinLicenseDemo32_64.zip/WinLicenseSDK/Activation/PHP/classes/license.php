<?php 

/******************************************************************************
 * License Class
 *****************************************************************************/
class License {
    public $custom_data = "";
    public $hardware_id = "";
    public $expiration_days = "";
    public $expiration_executions = "";
    public $expiration_date = "";
    public $expiration_runtime = "";
    public $expiration_global_time = "";
    public $country_lock = "";
    public $store_creation_date = "";
    public $network_instances = "";
    public $embed_user_info = "";
    public $is_unicode = "";
    public $install_before_date = "";
    public $insert_start_end_markers = "";
    public $activation_simultaneous_devices = "";
    public $activation_deactivation_limit = "";
    public $activation_activation_limit = "";
    public $activation_max_different_devices = "";
    public $activation_expiration_date = "";
    public $activation_key_format = "#####-#####-#####-#####-#####";
    public $order_subscription_days = SUBCRIPTION_200_YEARS;
    public $license_type = LICENSE_TYPE_FILE;
}

