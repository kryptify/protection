<?php

include_once "activation/constants.php";
include_once "activation/aux_functions.php";
include_once "activation/activate.php";
include_once "activation/deactivate.php";
include_once "activation/generate_license.php";

?>
