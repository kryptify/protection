Please, refer to the Help File (section "WinLicense --> Protecting an application --> Activation --> "Set everything up") 
for information about where to place these files in your web server