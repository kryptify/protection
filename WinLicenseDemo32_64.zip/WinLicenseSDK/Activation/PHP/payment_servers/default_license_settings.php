<?php

/******************************************************************************
 * SetDefaultLicenseSettings
 *****************************************************************************/
function SetDefaultLicenseSettings($license_settings)
{
    // ***********************************************************************
    // Uncomment and set the specific value that you want for your
    // generated license for your payment processor
    // 
    // Notice that you can define all default license values in the 
    // "Custom Product Values" key-pairs in the Products settings in 
    // "WinLicense Orders Manager". So you don't need to specify them here
    // ***********************************************************************

    // $license_settings->custom_data = "your_default_value";
    // $license_settings->hardware_id = "your_default_value";
    // $license_settings->expiration_days = "your_default_value";
    // $license_settings->expiration_executions = "your_default_value";
    // $license_settings->expiration_date = "your_default_value";
    // $license_settings->expiration_runtime = "your_default_value";
    // $license_settings->expiration_global_time = "your_default_value";
    // $license_settings->country_lock = "your_default_value";
    // $license_settings->store_creation_date = "your_default_value";
    // $license_settings->network_instances = "your_default_value";
    // $license_settings->embed_user_info = "your_default_value";
    // $license_settings->is_unicode = "your_default_value";
    // $license_settings->install_before_date = "your_default_value";
    // $license_settings->insert_start_end_markers = "your_default_value";
    // $license_settings->activation_simultaneous_devices = "your_default_value";
    // $license_settings->activation_deactivation_limit = "your_default_value";
    // $license_settings->activation_activation_limit = "your_default_value";
    // $license_settings->activation_max_different_devices = "your_default_value";
    // $license_settings->activation_expiration_date = "your_default_value";
    // $license_settings->activation_key_format = "your_default_value";
    // $license_settings->order_subscription_days = "your_default_value";
    // $license_settings->license_type = LICENSE_TYPE_FILE; // LICENSE_TYPE_ACTIVATION .... 
}

?>

