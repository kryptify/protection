<?php

    // ******************************
    // DATABASE settings
    // ******************************
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "mylocaldb";

    // ******************************
    // KEY GENERATOR settings
    // ******************************

    // specify path of compiled generator. i.e: 
    // define("ACTIVATION_APP", "/var/www/html/keygen");
    // define("ACTIVATION_APP", "/home/my_user_name/public_html/cgi-bin/keygen");
    define("ACTIVATION_APP", "bin\win\keygen.exe");                                            

?>
