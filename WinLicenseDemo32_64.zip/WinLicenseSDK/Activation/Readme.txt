Please, refer to the Help File (section "WinLicense --> Protecting an application --> Activation) 
to learn how to work with the Activation module in WinLicense