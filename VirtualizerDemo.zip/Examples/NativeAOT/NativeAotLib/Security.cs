﻿using System.Runtime.InteropServices;

namespace NativeAotLib;

public static class Security
{
    [UnmanagedCallersOnly(EntryPoint = "CheckPassword")]
    public static bool CheckPassword(IntPtr passwordPtr)
    {
        VirtualizerSDK.VIRTUALIZER_TIGER_WHITE_START();
        var password = Marshal.PtrToStringUni(passwordPtr);
        var result = password == "testpassword";
        VirtualizerSDK.VIRTUALIZER_TIGER_WHITE_END();
        return result;
    }
    
    [UnmanagedCallersOnly(EntryPoint = "CheckPassword2")]
    public static bool CheckPassword2(IntPtr passwordPtr)
    {
        var result = Task.Run(async () => {
            VirtualizerSDK.VIRTUALIZER_START();
            var password = Marshal.PtrToStringUni(passwordPtr);

            var correctPassword = (await File.ReadAllLinesAsync("password.txt")).First();

            var result = password == correctPassword;
            VirtualizerSDK.VIRTUALIZER_END();
            return result;
        }).Result;
        
        return result;
    }
}