
Just include "VirtualizerSDK.h" in your source code.

The rest of the files are used by VirtualizerSDK.h if required.


