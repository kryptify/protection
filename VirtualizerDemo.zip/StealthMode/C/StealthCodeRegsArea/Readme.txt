How to add a Stealth Code area in your application
--------------------------------------------------

Description
-----------
With this method, you create two areas (caveats) inside your application code and data.

Area 1) This will be located in the data area of your application (which is normally a READ/WRITE section). 
        Code Virtualizer will insert the VM data here

Area 2) This will be located in the code section of your application (which is normally a READ/EXECUTE section).
        Code Virtualizer will insert here the VM code
        
Let's do it
-----------
1) Please, refer to the "main.c" example file which includes the description of the required elements to create a Stealth Area

2) When you are going to protect the application, go to the "Advanced Options" panel and insert the following entry:

OPTION_PROTECTION_PRESERVE_SECTIONS_FLAGS=YES


