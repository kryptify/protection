1) In Rust, we define the Stealth Area in the data section like:

static mut STEALTH_AREA: [u32; STEALTH_SIZE] = {
    let mut temp = [0u32; STEALTH_SIZE];
    temp[0] = 0xa1a2a3a4;
    temp[1] = 0xa4a3a2a1;
    temp[2] = 0xb1a1b2a2;
    temp[3] = 0xb8a8a1a1;
    temp[4] = 0xb6b5b3b6;
    temp[5] = 0xa2b2c2d2;
    temp[6] = 0xa9a8a2a2;
    temp[7] = 0xa0a9b9b8;
    temp
};


2) The "stealth_area" variable must be referenced somewhere in your code to
   avoid the compiler removing its declaration due to not being used. You can 
   just use a conditional which will be evaluated as false 
   Example:

    unsafe {
        if STEALTH_AREA[0] == 0x11111111 {
            println!("{}", STEALTH_AREA[0]);
        }
    }

