include!("VirtualizerSDK.rs");

const STEALTH_ONE_KB: usize = 1024 / 4;
const STEALTH_ONE_MB: usize = 1024 * STEALTH_ONE_KB;
const STEALTH_SIZE: usize = STEALTH_ONE_MB * 2;

static mut STEALTH_AREA: [u32; STEALTH_SIZE] = {
    let mut temp = [0u32; STEALTH_SIZE];
    temp[0] = 0xa1a2a3a4;
    temp[1] = 0xa4a3a2a1;
    temp[2] = 0xb1a1b2a2;
    temp[3] = 0xb8a8a1a1;
    temp[4] = 0xb6b5b3b6;
    temp[5] = 0xa2b2c2d2;
    temp[6] = 0xa9a8a2a2;
    temp[7] = 0xa0a9b9b8;
    temp
};

fn main() {
    unsafe {
        if STEALTH_AREA[0] == 0x11111111 {
            println!("{}", STEALTH_AREA[0]);
        }
    }

    unsafe { VIRTUALIZER_START(); }
    println!("Hello from VIRTUALIZER macro!"); 
    unsafe { VIRTUALIZER_END(); }

    unsafe { VIRTUALIZER_TIGER_WHITE_START(); }
    println!("Hello from TIGER_WHITE macro!");
    unsafe { VIRTUALIZER_TIGER_WHITE_END(); }

    unsafe { VIRTUALIZER_FISH_WHITE_START(); }
    println!("Hello from FISH_WHITE macro!");
    unsafe { VIRTUALIZER_FISH_WHITE_END(); } 
}

