#include <VirtualizerSDK.h>

// *****************************************************************************
// Here, please, increase the number of chunks for data and code
// You might need to increase this value if you add more VMs or 
// add complex VMs
// *****************************************************************************
#define NUMBER_OF_DATA_CHUNKS 2
#define NUMBER_OF_CODE_CHUNKS 4


// Create space for VM data and VM code in the .text and .data sections
#define _1KB (1024)
#define _32KB (_1KB * 32)
#define _512KB (_1KB * 512)

#define STEALTH_DATA_CHUNK _32KB
#define STEALTH_CODE_CHUNK _512KB

template <size_t Size>
struct STEALTH_AREA {
    unsigned int Start[4];
    char Buffer[Size];
    unsigned int End[4];
};

// Data storage for VMs.
#pragma data_seg(".data")
__declspec(allocate(".data")) 
        STEALTH_AREA<STEALTH_DATA_CHUNK * NUMBER_OF_DATA_CHUNKS> StealthDataArea =
{
        { 0xA5A6A7A8, 0xA8A7A6A5, 0xB5A5B6A6, 0xB7A7A5A5 },
        { 0 },
        { 0xB8B7B6B5, 0xA6B6C6D6, 0xA7A6A4A4, 0xA4A5B1B2 }
};

// Code storage for VMs.
#pragma code_seg(".text")
__declspec(allocate(".text")) 
        STEALTH_AREA<STEALTH_CODE_CHUNK * NUMBER_OF_CODE_CHUNKS> StealthCodeArea =
{
        { 0xA1A2A3A4, 0xA4A3A2A1, 0xB1A1B2A2, 0xB8A8A1A1 },
        { 0 },
        { 0xB6B5B3B6, 0xA2B2C2D2, 0xA9A8A2A2, 0xA0A9B9B8 }
};
