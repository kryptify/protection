The main idea behind Code Virtualizer is that it generates code that is entirely platform-independent. Additionally, it makes only minor changes to the original layout of the protected binary, without altering the original entry point, imported functions, or other critical components. This brings significant benefits: if the protected code works on one computer, it will work on any computer, and if it fails on one, it will fail on all. This consistency simplifies and stabilizes the testing process. Another benefit is that it tends to lower the detection score of antivirus heuristic engines, thereby reducing the likelihood of false positives.

When the "Compress Virtual Machine" option is selected, the virtual machine and virtualized opcodes are compressed. Since the virtualized code is platform-independent, Code Virtualizer cannot rely on system calls to unprotect pages to perform the decompression process at runtime.

To facilitate the uncompression of the VMs, you must first modify the protection of the executable pages to make them writable. After this, you can call an initial VIRTUALIZER protection macro, which will uncompress all the VMs and virtualized code. Once the initial VIRTUALIZER macro has executed, you can restore the original page attributes and continue execution normally. In summary, the first VIRTUALIZER macro that runs in your code will detect that the VM is compressed and will initiate the uncompression process.

Subsequent VIRTUALIZER macros do not need to repeat this process, as the VMs will have already been uncompressed.

To assist with unprotecting and re-protecting the pages, you can use the "MemoryProtection" module, which is provided for each specific OS.

Here is an example of how to perform the above process using the "CVSectionHelper" module:

[For Mac, we use a different method, please refer to the file /Mac/Readme.txt]


int main()
{
    // Unprotect the "code virtualizer" section to allow its decompression.
    // This is done only once before the first "VIRTUALIZER" macro is executed.
    // The initial VIRTUALIZER macro will detect that the VM is compressed 
    // and will proceed with decompression

    PageInfo pageInfo = CVSetSectionAsWritable(".vlizer");

    VIRTUALIZER_START

        printf("This is my first VIRTUALIZER macro");

    VIRTUALIZER_END

    // Restore the original page attributtes for the code virtualizer section

    CVRestoreSectionAttributtes(&pageInfo);

    // Subsequent VIRTUALIZER macros do not need to unprotect the section again,
    // because all the VMs are already decompressed

    VIRTUALIZER_START

        printf("This is my second VIRTUALIZER macro");

    VIRTUALIZER_END

    return 0;
}
