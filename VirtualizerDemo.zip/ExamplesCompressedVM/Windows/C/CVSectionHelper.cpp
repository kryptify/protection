/*****************************************************************************
; Module: CVSectionHelper.cpp
; Description: Functions to modify and restore virtualizer section in runtime
;
; Authors: Oreans Technologies
; (c) 2024 Oreans Technologies
;****************************************************************************/

/******************************************************************************
;                                Includes
;*****************************************************************************/

#include "CVSectionHelper.h"

/******************************************************************************
;                                  Code
;*****************************************************************************/

/******************************************************************************
 * CVSetSectionAsWritable
 *****************************************************************************/
PageInfo 
CVSetSectionAsWritable(
    const char* sectionName) 
{
    PageInfo pageInfo = { NULL, 0 }; 

    HMODULE hModule = GetModuleHandle(NULL);
    if (!hModule) 
    {
        return pageInfo;
    }

    // Get the DOS header
    PIMAGE_DOS_HEADER pDOSHeader = (PIMAGE_DOS_HEADER)hModule;
    if (pDOSHeader->e_magic != IMAGE_DOS_SIGNATURE) 
    {
        return pageInfo;
    }

    // Get the NT header
    PIMAGE_NT_HEADERS pNTHeaders = (PIMAGE_NT_HEADERS)((BYTE*)hModule + pDOSHeader->e_lfanew);
    if (pNTHeaders->Signature != IMAGE_NT_SIGNATURE) 
    {
        return pageInfo;
    }

    BOOL is64Bit = FALSE;
    PIMAGE_SECTION_HEADER pSectionHeader;
    DWORD numberOfSections;

    // Check the file's architecture
    if (pNTHeaders->FileHeader.Machine == IMAGE_FILE_MACHINE_AMD64 || 
        pNTHeaders->FileHeader.Machine == IMAGE_FILE_MACHINE_ARM64)
    {
        PIMAGE_NT_HEADERS64 pNTHeaders64 = (PIMAGE_NT_HEADERS64)pNTHeaders;
        pSectionHeader = IMAGE_FIRST_SECTION(pNTHeaders64);
        numberOfSections = pNTHeaders64->FileHeader.NumberOfSections;
    }
    else if (pNTHeaders->FileHeader.Machine == IMAGE_FILE_MACHINE_I386) 
    {
        PIMAGE_NT_HEADERS32 pNTHeaders32 = (PIMAGE_NT_HEADERS32)pNTHeaders;
        pSectionHeader = IMAGE_FIRST_SECTION(pNTHeaders32);
        numberOfSections = pNTHeaders32->FileHeader.NumberOfSections;
    }
    else 
    {
        // Unsupported architecture
        return pageInfo;
    }

    // Loop through the sections
    for (DWORD i = 0; i < numberOfSections; i++) 
    {
        // Compare the section name with the provided section name
        if (strncmp((char*)pSectionHeader[i].Name, sectionName, IMAGE_SIZEOF_SHORT_NAME) == 0) 
        {
            // Check if the section has read+execute permissions
            if (pSectionHeader[i].Characteristics & IMAGE_SCN_MEM_EXECUTE &&
                pSectionHeader[i].Characteristics & IMAGE_SCN_MEM_READ &&
                !(pSectionHeader[i].Characteristics & IMAGE_SCN_MEM_WRITE)) 
            {
                DWORD oldProtect;
                DWORD newProtect = PAGE_EXECUTE_READWRITE;
                void* sectionBase = (void*)((BYTE*)hModule + pSectionHeader[i].VirtualAddress);
                SIZE_T sectionSize = pSectionHeader[i].Misc.VirtualSize;

                // Change the protection
                if (VirtualProtect(sectionBase, sectionSize, newProtect, &oldProtect)) 
                {
                    pageInfo.baseAddress = sectionBase;
                    pageInfo.regionSize = sectionSize;

                }
            }
            break; // section has been found, we can just exit
        }
    }
    return pageInfo;
}

/******************************************************************************
 * CVRestoreSectionAttributtes
 *****************************************************************************/
void 
CVRestoreSectionAttributtes(
    PageInfo* pageInfo) 
{
    if (!pageInfo || pageInfo->baseAddress == NULL) 
    {
        return;
    }

    DWORD oldProtect;
    VirtualProtect(pageInfo->baseAddress, pageInfo->regionSize, 
                   PAGE_EXECUTE_READ, &oldProtect);
}