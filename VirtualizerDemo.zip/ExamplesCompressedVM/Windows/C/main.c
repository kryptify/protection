/*****************************************************************************
; Module: main.cpp
; Description:
;
; Authors: Oreans Technologies
; (c) 2024 Oreans Technologies
;****************************************************************************/

/******************************************************************************
;                                Includes
;*****************************************************************************/

#include <stdio.h>
#include "CVSectionHelper.h"
#include "VirtualizerSDK.h"

/******************************************************************************
;                                  Code
;*****************************************************************************/

/******************************************************************************
 * main
 *****************************************************************************/
int 
main()
{
    // Unprotect the "code virtualizer" section to allow its decompression.
    // This is done only once before the first "VIRTUALIZER" macro is executed.
    // The initial VIRTUALIZER macro will detect that the VM is compressed 
    // and will proceed with decompression
    PageInfo pageInfo = CVSetSectionAsWritable(".vlizer");

    VIRTUALIZER_START

        printf("This is my first VIRTUALIZER macro");

    VIRTUALIZER_END

    // Restore the original page attributtes for the code virtualizer section
    CVRestoreSectionAttributtes(&pageInfo);

    // Subsequent VIRTUALIZER macros do not need to unprotect the section again,
    // because all the VMs are already decompressed
    VIRTUALIZER_START

        printf("This is my second VIRTUALIZER macro");

    VIRTUALIZER_END

    return 0;
}
