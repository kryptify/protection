/*****************************************************************************
; Header: CVSectionHelper.h
; Description: Function prototypes for CVSectionHelper.cpp
;
; Authors: Oreans Technologies
; (c) 2024 Oreans Technologies
;****************************************************************************/

#pragma once 

/******************************************************************************
;                                Includes
;*****************************************************************************/

#include <windows.h>

/******************************************************************************
;                                Typedefs
;*****************************************************************************/

typedef struct
{
    LPVOID baseAddress;
    SIZE_T regionSize;
} PageInfo;

/******************************************************************************
;                                Prototypes
;*****************************************************************************/

PageInfo CVSetSectionAsWritable(const char* sectionName);
void CVRestoreSectionAttributtes(PageInfo* pageInfo);


