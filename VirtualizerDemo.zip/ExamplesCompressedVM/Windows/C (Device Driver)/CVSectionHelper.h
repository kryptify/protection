/*****************************************************************************
; Header: CVSectionHelper.h
; Description: Function prototypes for memory protection operations in a 
;              device driver
;
; Authors: Oreans Technologies
; (c) 2024 Oreans Technologies
;*****************************************************************************/

#ifndef _CVSECTIONHELPER_H_
#define _CVSECTIONHELPER_H_

/******************************************************************************
;                                Includes
;*****************************************************************************/

#include <ntddk.h>

/******************************************************************************
;                                Typedefs
;*****************************************************************************/

typedef struct _PAGE_INFO
{
    PVOID baseAddress;
    SIZE_T regionSize;
} PAGE_INFO, *PPAGE_INFO;

/******************************************************************************
;                                Prototypes
;*****************************************************************************/

PageInfo CVSetSectionAsWritable(const char* sectionName);
void CVRestoreSectionAttributtes(PageInfo* pageInfo);

#endif // _CVSECTIONHELPER_H_
