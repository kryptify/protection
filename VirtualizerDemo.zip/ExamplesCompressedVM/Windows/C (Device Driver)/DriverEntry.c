/*****************************************************************************
; Module: DriverEntry.c
; Description: Example of a Windows kernel-mode driver using memory protection 
;              and virtualization techniques.
;
; Authors: Oreans Technologies
; (c) 2024 Oreans Technologies
;*****************************************************************************/

/******************************************************************************
;                                Includes
;*****************************************************************************/

#include <ntddk.h>
#include "CVSectionHelper.h"
#include "VirtualizerSDK.h"

/******************************************************************************
;                                  Code
;*****************************************************************************/

/******************************************************************************
 * DriverEntry
 *****************************************************************************/
NTSTATUS
DriverEntry(
    _In_ PDRIVER_OBJECT DriverObject,
    _In_ PUNICODE_STRING RegistryPath)
{
    UNREFERENCED_PARAMETER(DriverObject);
    UNREFERENCED_PARAMETER(RegistryPath);

    // Unprotect Read+Execute pages by setting them to Read+Write+Execute
    // before calling the first VIRTUALIZER macro. This allows the VM to
    // be uncompressed in memory.
    PageInfo pageInfo = CVSetSectionAsWritable(".vlizer");

    VIRTUALIZER_START

        DbgPrint("This is my first VIRTUALIZER macro\n");

    VIRTUALIZER_END

    // The VM has been uncompressed. We can now restore the executable pages
    // to Read+Execute.
    CVRestoreSectionAttributtes(&pageInfo);

    // You can continue execution normally, other VIRTUALIZER macros do not 
    // need to unprotect pages again

    VIRTUALIZER_START

        DbgPrint("This is my second VIRTUALIZER macro\n");

    VIRTUALIZER_END

    return STATUS_SUCCESS;
}
