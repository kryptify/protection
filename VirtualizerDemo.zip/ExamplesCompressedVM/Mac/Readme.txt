[Please, contact us at support@oreans.com to obtain this example source code]

Due to security restrictions on macOS, particularly on Apple Silicon (M1, M2, etc.), it is not possible to unprotect the LOAD segment of an executable to set it to RWX (Read, Write, Execute) permissions. These restrictions are part of macOS's security design, which prevents modifications to executable memory regions to maintain system integrity and protect against potential exploits.

As a result, the decompression of the Virtual Machine is performed directly within the target application instead of relying on Code Virtualizer decompression code.

This approach allows the software to maintain compatibility with macOS's security requirements while still performing the necessary decompression operations efficiently.

Please refer to the main.c file to learn how to perform the decompression of all the inserted VMs.
