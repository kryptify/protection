/*****************************************************************************
; Module: CVSectionHelper.cpp
; Description: Functions to modify and restore the virtualizer section in runtime
;
; Authors: Oreans Technologies
; (c) 2024 Oreans Technologies
;****************************************************************************/

/******************************************************************************
;                                Includes
;*****************************************************************************/

#define _GNU_SOURCE
#include <dlfcn.h>
#include <stdlib.h>      
#include <sys/types.h>       
#include <sys/mman.h>    
#include <string.h>
#include <stdio.h>
#include <elf.h>
#include <link.h>
#include "CVSectionHelper.h"

/******************************************************************************
;                                  Code
;*****************************************************************************/

/******************************************************************************
 * CVSetVMSegmentWritable
 *****************************************************************************/
PageInfo 
CVSetVMSegmentWritable() 
{
    PageInfo pageInfo = { NULL, 0 };
    Dl_info dl_info;

    if (!dladdr((void*)&CVSetVMSegmentWritable, &dl_info)) 
    {
        return pageInfo;
    }

    // Get the base address of the current executable
    const uint8_t* baseAddress = (const uint8_t*)dl_info.dli_fbase;

    // Determine if it's ELF32 or ELF64
    const unsigned char* ident = baseAddress;

    const uint8_t targetBytes[] = {0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
    size_t targetSize = sizeof(targetBytes);

    if (ident[EI_CLASS] == ELFCLASS32) 
    {
        // Handle ELF32 format
        const Elf32_Ehdr* header = (const Elf32_Ehdr*)baseAddress;

        if (header->e_ident[EI_MAG0] != ELFMAG0 || 
            header->e_ident[EI_MAG1] != ELFMAG1 || 
            header->e_ident[EI_MAG2] != ELFMAG2 || 
            header->e_ident[EI_MAG3] != ELFMAG3) 
        {
            return pageInfo;
        }

        const Elf32_Phdr* programHeaders = 
            (const Elf32_Phdr*)(baseAddress + header->e_phoff);

        for (int i = 0; i < header->e_phnum; i++) 
        {
            const Elf32_Phdr* programHeader = &programHeaders[i];

            if (programHeader->p_type == PT_LOAD && programHeader->p_flags == (PF_R | PF_W))
            {
                // Get the segment's base address and size
                void* segmentBase = (void*)(baseAddress + programHeader->p_vaddr);

                // Check if the segment contains the target byte sequence
                if (memcmp(segmentBase, targetBytes, targetSize) == 0) 
                {
                    size_t segmentSize = programHeader->p_memsz;

                    // Change the protection to read-write-execute
                    if (mprotect(segmentBase, segmentSize, PROT_READ | PROT_WRITE | 
                                 PROT_EXEC) == 0) 
                    {
                        pageInfo.baseAddress = segmentBase;
                        pageInfo.regionSize = segmentSize;
                    }
                    else 
                    {
                        printf("mprotect failed at base address: %p, size: 0x%zx bytes\n", segmentBase, segmentSize);
                    }
                    return pageInfo; 
                }
            }
        }
    } 
    else if (ident[EI_CLASS] == ELFCLASS64) 
    {
        // Handle ELF64 format
        const Elf64_Ehdr* header = (const Elf64_Ehdr*)baseAddress;

        if (header->e_ident[EI_MAG0] != ELFMAG0 || 
            header->e_ident[EI_MAG1] != ELFMAG1 || 
            header->e_ident[EI_MAG2] != ELFMAG2 || 
            header->e_ident[EI_MAG3] != ELFMAG3) 
        {
            return pageInfo;
        }

        const Elf64_Phdr* programHeaders = 
            (const Elf64_Phdr*)(baseAddress + header->e_phoff);

        for (int i = 0; i < header->e_phnum; i++) 
        {
            const Elf64_Phdr* programHeader = &programHeaders[i];

            if (programHeader->p_type == PT_LOAD && programHeader->p_flags == (PF_R | PF_W))
            {
                // Get the segment's base address and size
                void* segmentBase = (void*)(baseAddress + programHeader->p_vaddr);

                // Check if the segment contains the target byte sequence
                if (memcmp(segmentBase, targetBytes, targetSize) == 0) 
                {
                    size_t segmentSize = programHeader->p_memsz;

                    // Change the protection to read-write-execute
                    if (mprotect(segmentBase, segmentSize, PROT_READ | PROT_WRITE | 
                                 PROT_EXEC) == 0) 
                    {
                        pageInfo.baseAddress = segmentBase;
                        pageInfo.regionSize = segmentSize;
                    }
                    else 
                    {
                        printf("mprotect failed at base address: %p, size: 0x%zx bytes\n", segmentBase, segmentSize);
                    }
                    return pageInfo; 
                }
            }
        }
    }
    return pageInfo;
}

/******************************************************************************
 * CVSetVMSegmentNotWritable
 *****************************************************************************/
void 
CVSetVMSegmentNotWritable(
    PageInfo pageInfo) 
{
    if (pageInfo.baseAddress != NULL) 
    {
        mprotect(pageInfo.baseAddress, pageInfo.regionSize, 
                 PROT_READ | PROT_EXEC);
    }
}
