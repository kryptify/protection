/*****************************************************************************
; Header: CVSectionHelper.h
; Description: Function prototypes for CVSectionHelper.cpp
;
; Authors: Oreans Technologies
; (c) 2024 Oreans Technologies
;****************************************************************************/

#pragma once 

/******************************************************************************
;                                Typedefs
;*****************************************************************************/

typedef struct
{
    void* baseAddress;
    size_t regionSize;
} PageInfo;

/******************************************************************************
;                                Prototypes
;*****************************************************************************/

PageInfo CVSetVMSegmentWritable();
void CVSetVMSegmentNotWritable(PageInfo pageInfo);


